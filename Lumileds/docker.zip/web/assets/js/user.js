import Vue from 'vue';
import $ from 'jquery';

new Vue({
    el: '#user',
    data: {
        group: $('#user_group').val()
    },
});
