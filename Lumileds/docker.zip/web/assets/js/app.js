let $ = require('jquery');
require('select2');
require('bootstrap-sass');
require('../css/app.scss');
require('jquery-file-download');

global.$ = global.jQuery = $;

require('bootstrap-editable');
