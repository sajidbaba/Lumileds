<?php

namespace AppBundle\Exception;


class UploadSheetException extends \Exception
{
}
