<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

class ContributionApproveRepository extends EntityRepository
{
}
