<?php

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;

class ContributionIndicatorRequestRepository extends EntityRepository
{

}
