<?php

namespace AppBundle\Indicators;

interface PercentageIndicatorInterface
{
}
